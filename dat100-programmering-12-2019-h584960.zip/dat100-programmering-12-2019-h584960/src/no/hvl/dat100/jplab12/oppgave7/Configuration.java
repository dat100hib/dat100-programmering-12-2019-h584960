package no.hvl.dat100.jplab12.oppgave7;

public class Configuration {

		public static int SERVERPORT = 8080;
		
		public static String SERVER = "localhost";
		
		public static int N = 3;
		
}
